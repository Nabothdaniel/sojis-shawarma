<?php

/**
 * BamzySMS - Main Entry Point
 * This file is now modular and clean.
 */

$base = file_exists(__DIR__ . '/src/bootstrap.php') ? __DIR__ : __DIR__ . '/..';
require_once $base . '/src/bootstrap.php';

// Load routes
$router = require_once $base . '/routes/api.php';

// Resolve request
$router->resolve();
